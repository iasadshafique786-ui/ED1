import Header from '@/components/Header';
import { HeroSection } from '@/components/HeroSection';
import { PathwaySection } from '@/components/PathwaySection';
import { CoursesSection } from '@/components/CoursesSection';
import { FeaturesSection } from '@/components/FeaturesSection';
import { BoostSection } from '@/components/BoostSection';
import { TeamSection } from '@/components/TeamSection';
import { AboutSection } from '@/components/AboutSection';
import { ContactSection } from '@/components/ContactSection';
import { FreeSessionSection } from '@/components/FreeSessionSection';
import { Footer } from '@/components/Footer';

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <HeroSection />
      <PathwaySection />
      <CoursesSection />
      <FeaturesSection />
      <BoostSection />
      <TeamSection />
      <AboutSection />
      <ContactSection />
      <FreeSessionSection />
      <Footer />
    </div>
  );
};

export default Index;
