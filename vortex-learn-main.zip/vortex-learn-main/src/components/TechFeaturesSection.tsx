import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Brain, Headphones, Shield, Smartphone, Zap, Globe } from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: "AI-Powered Learning",
    description: "Personalized learning paths adapted to your pace and style",
    stats: "98% completion rate"
  },
  {
    icon: Headphones,
    title: "VR/AR Ready",
    description: "Immersive virtual reality experiences for hands-on learning",
    stats: "360° learning"
  },
  {
    icon: Shield,
    title: "Blockchain Certified",
    description: "Secure, verifiable certificates on the blockchain",
    stats: "100% authentic"
  },
  {
    icon: Smartphone,
    title: "Mobile First",
    description: "Learn anywhere, anytime on any device",
    stats: "24/7 access"
  },
  {
    icon: Zap,
    title: "Real-Time Progress",
    description: "Live analytics and performance tracking",
    stats: "Live tracking"
  },
  {
    icon: Globe,
    title: "Global Community",
    description: "Connect with learners and mentors worldwide",
    stats: "150+ countries"
  }
];

export const TechFeaturesSection = () => {
  return (
    <section className="py-24 bg-muted/20 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-futuristic font-black mb-6">
            <span className="text-foreground">Platform</span> <span className="text-accent-glow">Features</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Experience the future of education with cutting-edge technology and innovative learning solutions
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card 
              key={index}
              className="group relative p-8 bg-gradient-card border-border/50 hover-glow cursor-pointer transition-all duration-500 animate-scale-up"
              style={{ animationDelay: `${index * 0.15}s` }}
            >
              {/* Icon */}
              <div className="relative mb-6">
                <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center group-hover:bg-primary/30 transition-colors duration-300">
                  <feature.icon className="w-8 h-8 text-primary group-hover:scale-110 transition-transform duration-300" />
                </div>
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-accent rounded-full animate-pulse-glow"></div>
              </div>
              
              {/* Content */}
              <h3 className="text-xl font-futuristic font-bold text-foreground mb-3 group-hover:text-neon-glow transition-colors duration-300">
                {feature.title}
              </h3>
              
              <p className="text-muted-foreground mb-4 leading-relaxed">
                {feature.description}
              </p>
              
              {/* Stats Badge */}
              <div className="inline-flex items-center px-3 py-1 bg-accent/20 text-accent text-sm rounded-full font-medium border border-accent/30">
                {feature.stats}
              </div>
              
              {/* Hover Glow */}
              <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-accent/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-lg"></div>
            </Card>
          ))}
        </div>
        
        <div className="text-center mt-16">
          <Button variant="plasma" size="lg" className="text-lg px-8 py-6">
            Explore All Features
          </Button>
        </div>
      </div>
    </section>
  );
};