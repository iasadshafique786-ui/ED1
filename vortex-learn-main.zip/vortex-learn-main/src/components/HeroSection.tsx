import React from 'react';
import { Button } from '@/components/ui/button';
import { Play } from 'lucide-react';
import heroImage from '@/assets/hero-image.jpg';

export const HeroSection = () => {
  return (
    <section className="relative min-h-[80vh] bg-background flex items-center">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-6">
              <h1 className="text-5xl lg:text-6xl font-bold text-primary leading-tight">
                WorldeCampus
              </h1>
              <div className="space-y-2">
                <div className="bg-primary text-primary-foreground px-6 py-3 rounded-lg inline-block text-xl font-semibold">
                  Advanced Online Academic Trainings
                </div>
                <div className="bg-primary text-primary-foreground px-6 py-3 rounded-lg inline-block text-xl font-semibold block">
                  For Every Student in Every Home
                </div>
              </div>
              
              <p className="text-lg text-muted-foreground max-w-2xl">
                We help humans in adopting advanced learning patterns through academic trainings
              </p>
            </div>
            
            <div className="space-y-4">
              <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-4 text-lg font-semibold rounded-lg">
                GET YOUR FREE SESSION
              </Button>
              <div className="text-sm text-muted-foreground">
                (Limited slots left)
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="lg" className="text-primary hover:text-primary/80 p-0">
                <div className="flex items-center gap-2">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                    <Play className="w-6 h-6 text-primary" />
                  </div>
                  <span className="text-lg font-medium">Watch Video</span>
                </div>
              </Button>
            </div>
          </div>
          
          <div className="relative">
            <img 
              src={heroImage} 
              alt="Students learning together" 
              className="w-full h-auto rounded-lg shadow-lg"
            />
          </div>
        </div>
      </div>
    </section>
  );
};