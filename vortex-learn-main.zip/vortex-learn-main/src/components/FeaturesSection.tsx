import React from 'react';
import { Card } from '@/components/ui/card';

const features = [
  {
    title: "One on One Collaborations",
    description: "Personalized learning with dedicated instructors",
    icon: "👩‍🏫",
  },
  {
    title: "Personalized Schedules", 
    description: "Flexible timing that fits your family's routine",
    icon: "👨‍👩‍👦",
  },
  {
    title: "Advanced Tools & Technologys",
    description: "Modern learning tools and interactive platforms",
    icon: "👩‍💻",
  },
  {
    title: "Learn Anywhere Online",
    description: "Access quality education from anywhere",
    icon: "👦",
  }
];

export const FeaturesSection = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="inline-block bg-blue-100 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            FEATURES
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-primary">
            Smart Features Of World e Campus
          </h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="p-6 text-center hover:shadow-lg transition-shadow bg-white border border-gray-200">
              <div className="mb-6">
                <div className="w-full h-48 bg-gray-100 rounded-lg mb-4 flex items-center justify-center text-6xl">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">{feature.title}</h3>
                <p className="text-muted-foreground text-sm">{feature.description}</p>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};