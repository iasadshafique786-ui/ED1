import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

const courses = [
  {
    title: "Mathematics",
    description: "Build strong mathematical foundations with expert guidance",
    icon: "🔢",
  },
  {
    title: "Science", 
    description: "Explore the wonders of science through interactive learning",
    icon: "⚗️",
  },
  {
    title: "Computer",
    description: "Master technology and programming skills for the future",
    icon: "💻",
  },
  {
    title: "English",
    description: "Enhance language skills and communication abilities", 
    icon: "📚",
  },
  {
    title: "Holy Quran",
    description: "Learn and understand the Holy Quran with proper guidance",
    icon: "📖",
  },
  {
    title: "Home Work",
    description: "Get personalized help with homework and assignments",
    icon: "✏️",
  }
];

export const CoursesSection = () => {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="inline-block bg-blue-100 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            COURSES
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold mb-4">
            Our Popular <span className="text-primary">Courses</span>
          </h2>
          <div className="bg-primary text-primary-foreground px-6 py-2 rounded-lg inline-block text-lg font-semibold mb-4">
            Grade 01 to Grade 013 KS2, KS3, GCSE, A-level, SATs, 11+, 13+
          </div>
          <p className="text-lg text-muted-foreground">
            Enhance your skills by our popular courses
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map((course, index) => (
            <Card key={index} className="p-8 text-center hover:shadow-lg transition-shadow border border-gray-200">
              <div className="mb-6">
                <div className="text-6xl mb-4">{course.icon}</div>
                <h3 className="text-2xl font-bold text-foreground mb-4">{course.title}</h3>
                <p className="text-muted-foreground mb-6">{course.description}</p>
              </div>
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 py-2 rounded-lg font-semibold">
                Get Your Free Session
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};