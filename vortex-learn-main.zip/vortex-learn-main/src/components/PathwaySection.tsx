import React from 'react';
import { Button } from '@/components/ui/button';

export const PathwaySection = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <h2 className="text-4xl lg:text-5xl font-bold text-foreground leading-tight">
              Your Kid's Exciting Pathway towards 
              <span className="block">Academic Mastery is Just One Decision</span>
              <span className="block">Away.</span>
            </h2>
            
            <p className="text-lg text-muted-foreground leading-relaxed">
              The journey of thousand miles starts with the first step. A free trial 
              session will help you and your kid in deciding a track that surely 
              leads towards mastery of the academic material enabling you to 
              bring your desired academic outcomes.
            </p>
            
            <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-4 text-lg font-semibold rounded-lg">
              GET YOUR FREE SESSION
            </Button>
          </div>
          
          <div className="relative">
            <div className="bg-gradient-to-br from-blue-500 to-blue-700 rounded-lg p-12 text-white relative overflow-hidden">
              <div className="relative z-10">
                <div className="flex flex-col items-center space-y-8">
                  {/* Steps illustration */}
                  <div className="relative">
                    <div className="flex flex-col items-end space-y-4">
                      <div className="w-24 h-6 bg-white/20 rounded"></div>
                      <div className="w-20 h-6 bg-white/30 rounded"></div>
                      <div className="w-16 h-6 bg-white/40 rounded"></div>
                      <div className="w-12 h-6 bg-white/50 rounded"></div>
                    </div>
                    {/* Person icon */}
                    <div className="absolute -top-8 -right-4">
                      <div className="w-12 h-12 bg-white/80 rounded-full flex items-center justify-center">
                        <div className="w-8 h-8 bg-blue-500 rounded-full"></div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <h3 className="text-3xl font-bold mb-2">SUCCESS</h3>
                  </div>
                </div>
              </div>
              
              {/* Decorative elements */}
              <div className="absolute top-4 left-4 w-8 h-8 bg-white/10 rounded-full"></div>
              <div className="absolute bottom-8 left-8 w-6 h-6 bg-white/15 rounded-full"></div>
              <div className="absolute top-1/2 right-8 w-4 h-4 bg-white/20 rounded-full"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};