import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export const FreeSessionSection = () => {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Get Your Free Session
          </h2>
          <p className="text-lg text-muted-foreground">
            Fill-up the below form for your Get Your Free Session classes.
          </p>
        </div>
        
        <div className="bg-white rounded-lg shadow-lg p-8">
          <form className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input 
                placeholder="Your Name" 
                className="border-gray-300 focus:border-primary h-12"
              />
              <Input 
                placeholder="Your Email" 
                type="email"
                className="border-gray-300 focus:border-primary h-12"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input 
                placeholder="Cell no" 
                type="tel"
                className="border-gray-300 focus:border-primary h-12"
              />
              <Select>
                <SelectTrigger className="border-gray-300 focus:border-primary h-12">
                  <SelectValue placeholder="Select a subject" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mathematics">Mathematics</SelectItem>
                  <SelectItem value="science">Science</SelectItem>
                  <SelectItem value="computer">Computer</SelectItem>
                  <SelectItem value="english">English</SelectItem>
                  <SelectItem value="quran">Holy Quran</SelectItem>
                  <SelectItem value="homework">Home Work</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Select>
              <SelectTrigger className="border-gray-300 focus:border-primary h-12">
                <SelectValue placeholder="Select your country..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="us">United States</SelectItem>
                <SelectItem value="uk">United Kingdom</SelectItem>
                <SelectItem value="ca">Canada</SelectItem>
                <SelectItem value="au">Australia</SelectItem>
                <SelectItem value="pk">Pakistan</SelectItem>
                <SelectItem value="in">India</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
            
            <Textarea 
              placeholder="Message" 
              rows={6}
              className="border-gray-300 focus:border-primary"
            />
            
            <div className="text-center">
              <Button 
                type="submit" 
                size="lg" 
                className="bg-primary hover:bg-primary/90 text-primary-foreground px-12 py-4 text-lg font-semibold rounded-lg"
              >
                Get Your Free Session Classes
              </Button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};