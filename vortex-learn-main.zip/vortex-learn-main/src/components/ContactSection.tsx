import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Mail, Phone } from 'lucide-react';

export const ContactSection = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="inline-block bg-blue-100 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            CONTACT
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-primary">
            Contact Us
          </h2>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div className="space-y-8">
            <Card className="p-8 text-center bg-white">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Mail className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-2">Email Us</h3>
              <p className="text-muted-foreground">worldecampus@gmail.com</p>
            </Card>
            
            <Card className="p-8 text-center bg-white">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-2">Call Us</h3>
              <p className="text-muted-foreground">+1 (315) 288-0008</p>
            </Card>
          </div>
          
          <div>
            <Card className="p-8 bg-white">
              <form className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input 
                    placeholder="Your Name" 
                    className="border-gray-300 focus:border-primary"
                  />
                  <Input 
                    placeholder="Your Email" 
                    type="email"
                    className="border-gray-300 focus:border-primary"
                  />
                </div>
                
                <Input 
                  placeholder="Subject" 
                  className="border-gray-300 focus:border-primary"
                />
                
                <Textarea 
                  placeholder="Message" 
                  rows={6}
                  className="border-gray-300 focus:border-primary"
                />
                
                <Button 
                  type="submit" 
                  size="lg" 
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground py-3 text-lg font-semibold rounded-lg"
                >
                  Send Message
                </Button>
              </form>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};