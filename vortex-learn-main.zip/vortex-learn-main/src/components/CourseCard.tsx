import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, Clock, Users, Star } from 'lucide-react';

interface CourseCardProps {
  title: string;
  description: string;
  image: string;
  duration: string;
  students: string;
  rating: number;
  tags: string[];
  price: string;
}

export const CourseCard = ({ title, description, image, duration, students, rating, tags, price }: CourseCardProps) => {
  const [isHovered, setIsHovered] = useState(false);
  
  return (
    <Card 
      className="group relative overflow-hidden bg-gradient-card border-border/50 hover-lift cursor-pointer transition-all duration-500"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image Container */}
      <div className="relative h-48 overflow-hidden">
        <img 
          src={image} 
          alt={title}
          className={`w-full h-full object-cover transition-transform duration-700 ${
            isHovered ? 'scale-110' : 'scale-100'
          }`}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent"></div>
        
        {/* Floating Price Tag */}
        <div className="absolute top-4 right-4 bg-primary/90 backdrop-blur-sm text-primary-foreground px-3 py-1 rounded-full text-sm font-futuristic font-bold">
          {price}
        </div>
        
        {/* Rating */}
        <div className="absolute top-4 left-4 flex items-center gap-1 bg-background/90 backdrop-blur-sm px-2 py-1 rounded-full">
          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
          <span className="text-sm font-semibold">{rating}</span>
        </div>
      </div>
      
      {/* Content */}
      <div className="p-6">
        <div className="flex flex-wrap gap-2 mb-3">
          {tags.map((tag, index) => (
            <span 
              key={index}
              className="px-2 py-1 bg-accent/20 text-accent text-xs rounded-full font-medium border border-accent/30"
            >
              {tag}
            </span>
          ))}
        </div>
        
        <h3 className="text-xl font-futuristic font-bold text-foreground mb-3 group-hover:text-neon-glow transition-colors duration-300">
          {title}
        </h3>
        
        <p className="text-muted-foreground mb-4 overflow-hidden">
          <span className="line-clamp-2">{description}</span>
        </p>
        
        {/* Stats */}
        <div className="flex items-center justify-between text-sm text-muted-foreground mb-6">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{duration}</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="w-4 h-4" />
            <span>{students}</span>
          </div>
        </div>
        
        {/* CTA */}
        <Button 
          variant="cyber" 
          className="w-full group-hover:shadow-glow-violet transition-all duration-300"
        >
          Enroll Now
          <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform duration-300" />
        </Button>
      </div>
      
      {/* Hover Glow Effect */}
      <div className={`absolute inset-0 bg-gradient-to-r from-primary/5 to-accent/5 opacity-0 transition-opacity duration-500 ${
        isHovered ? 'opacity-100' : 'opacity-0'
      }`}></div>
    </Card>
  );
};