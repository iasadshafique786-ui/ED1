import React from 'react';
import { Card } from '@/components/ui/card';

const teamMembers = [
  {
    name: "Haseeb Ahmad",
    image: "👨‍💼",
  },
  {
    name: "Hammad Tanveer", 
    image: "👨‍💼",
  },
  {
    name: "Imtiaz Ali Kazmi",
    image: "👨‍💼",
  },
  {
    name: "Sarah Khan",
    image: "👩‍💼",
  }
];

export const TeamSection = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="inline-block bg-blue-100 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            TEAM
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-primary">
            Top Management & Curriculam Managers
          </h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {teamMembers.map((member, index) => (
            <Card key={index} className="p-6 text-center hover:shadow-lg transition-shadow bg-white border border-gray-200">
              <div className="mb-6">
                <div className="w-32 h-32 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center text-4xl">
                  {member.image}
                </div>
                <h3 className="text-xl font-bold text-foreground">{member.name}</h3>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};