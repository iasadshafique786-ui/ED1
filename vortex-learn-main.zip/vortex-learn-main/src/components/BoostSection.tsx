import React from 'react';

const skills = [
  { name: "Creativity", position: { top: "15%", left: "25%" } },
  { name: "Logic", position: { top: "20%", right: "15%" } },
  { name: "Skills", position: { top: "30%", left: "15%" } },
  { name: "Memory", position: { top: "45%", left: "10%" } },
  { name: "Vision", position: { top: "35%", right: "20%" } },
  { name: "Motivation", position: { bottom: "25%", left: "20%" } },
  { name: "Intelligence", position: { bottom: "15%", right: "10%" } },
];

export const BoostSection = () => {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-8">
            A Boost up Package for Your Children
          </h2>
          
          <div className="relative max-w-4xl mx-auto h-96">
            {/* Central image placeholder */}
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
              <div className="w-32 h-40 bg-gray-200 rounded-lg flex items-center justify-center">
                <div className="text-4xl">👦</div>
              </div>
            </div>
            
            {/* Skill tags positioned around the image */}
            {skills.map((skill, index) => (
              <div
                key={index}
                className="absolute"
                style={skill.position}
              >
                <div className="bg-primary text-primary-foreground px-4 py-2 rounded-lg font-semibold text-sm shadow-lg">
                  {skill.name}
                </div>
                {/* Connector dots */}
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                  <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};