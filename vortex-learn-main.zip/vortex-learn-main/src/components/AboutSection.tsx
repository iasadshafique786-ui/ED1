import React from 'react';
import { Button } from '@/components/ui/button';

export const AboutSection = () => {
  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="inline-block bg-blue-100 text-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            ABOUT
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start">
          <div className="lg:col-span-1">
            <div className="text-center">
              <div className="w-48 h-60 bg-gray-200 rounded-lg mx-auto mb-6 flex items-center justify-center">
                <div className="text-6xl">👨‍💼</div>
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-2">Asad Shafique</h3>
              <p className="text-muted-foreground">(Founder/CEO)</p>
            </div>
          </div>
          
          <div className="lg:col-span-2 space-y-6">
            <p className="text-lg text-muted-foreground leading-relaxed italic">
              At WorldeCampus, through academic trainings, we help humans in adopting advanced learning patterns leading to maximise the academic performance.
            </p>
            
            <p className="text-lg text-muted-foreground leading-relaxed">
              WorldeCampus is successfully operating and growing exponentially since 2016, AlhamduLiLLAH. We use modern collaboration tools to interact and help students in solving their academic problems, practicing academic materials and to complete their home/school work.
            </p>
            
            <p className="text-lg text-muted-foreground leading-relaxed">
              Our expert education specialists are providing educational services across the globe and by delivering the outcome based excellent educational services we are gaining massive popularity especially in the first world countries. World e Campus is committed to be recognized as the world's top and largest online educational services provider having millions of professional tutors and students worldwide.
            </p>
            
            <div className="pt-6">
              <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground px-8 py-4 text-lg font-semibold rounded-lg">
                GET YOUR FREE SESSION
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};