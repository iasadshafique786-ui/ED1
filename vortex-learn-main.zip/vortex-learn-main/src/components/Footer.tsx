import React from 'react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Github, Twitter, Linkedin, Mail, Zap } from 'lucide-react';

export const Footer = () => {
  return (
    <footer className="bg-gradient-to-t from-muted/30 to-background py-16 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/3 w-64 h-64 bg-primary/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/3 w-64 h-64 bg-accent/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-gradient-primary rounded-xl flex items-center justify-center">
                <Zap className="w-6 h-6 text-primary-foreground" />
              </div>
              <h3 className="text-2xl font-futuristic font-bold text-neon-glow">FutureLearn</h3>
            </div>
            
            <p className="text-muted-foreground mb-6 max-w-md leading-relaxed">
              Empowering the next generation of innovators with cutting-edge education, 
              AI-powered learning, and futuristic skill development.
            </p>
            
            <div className="flex gap-4">
              <Button variant="ghost" size="icon" className="hover:text-primary hover:shadow-glow">
                <Github className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-primary hover:shadow-glow">
                <Twitter className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-primary hover:shadow-glow">
                <Linkedin className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="hover:text-primary hover:shadow-glow">
                <Mail className="w-5 h-5" />
              </Button>
            </div>
          </div>
          
          {/* Courses */}
          <div>
            <h4 className="text-lg font-futuristic font-semibold text-foreground mb-6">Courses</h4>
            <ul className="space-y-3">
              {['AI & Machine Learning', 'Virtual Reality', 'Cybersecurity', 'Blockchain', 'Data Science', 'Quantum Computing'].map((course) => (
                <li key={course}>
                  <a 
                    href="#" 
                    className="text-muted-foreground hover:text-accent transition-colors duration-300 hover:underline"
                  >
                    {course}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Company */}
          <div>
            <h4 className="text-lg font-futuristic font-semibold text-foreground mb-6">Company</h4>
            <ul className="space-y-3">
              {['About Us', 'Careers', 'Press', 'Blog', 'Partners', 'Contact'].map((item) => (
                <li key={item}>
                  <a 
                    href="#" 
                    className="text-muted-foreground hover:text-accent transition-colors duration-300 hover:underline"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <Separator className="border-border/50" />
        
        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row justify-between items-center pt-8 gap-6">
          <div className="text-muted-foreground text-sm">
            © 2024 FutureLearn. All rights reserved. Building tomorrow's leaders today.
          </div>
          
          <div className="flex gap-6 text-sm">
            <a href="#" className="text-muted-foreground hover:text-accent transition-colors duration-300">
              Privacy Policy
            </a>
            <a href="#" className="text-muted-foreground hover:text-accent transition-colors duration-300">
              Terms of Service
            </a>
            <a href="#" className="text-muted-foreground hover:text-accent transition-colors duration-300">
              Cookie Policy
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};