import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar } from '@/components/ui/avatar';
import { ChevronLeft, ChevronRight, Quote, Star } from 'lucide-react';

const testimonials = [
  {
    name: "Sarah Chen",
    role: "AI Engineer at Tesla",
    avatar: "SC",
    rating: 5,
    text: "The AI course completely transformed my career. The hands-on projects and cutting-edge curriculum prepared me for real-world challenges at Tesla."
  },
  {
    name: "Marcus Rodriguez",
    role: "VR Developer at Meta",
    avatar: "MR", 
    rating: 5,
    text: "Incredible VR program! The immersive learning experience was unlike anything I'd encountered. Now I'm building the metaverse at Meta."
  },
  {
    name: "Aisha Patel",
    role: "Blockchain Architect",
    avatar: "AP",
    rating: 5,
    text: "The cybersecurity and blockchain course gave me the skills to become a lead architect. The future-focused approach is unmatched."
  },
  {
    name: "David Kim",
    role: "Tech Lead at Google",
    avatar: "DK",
    rating: 5,
    text: "Outstanding platform with world-class instructors. The learning experience is smooth, engaging, and perfectly aligned with industry needs."
  }
];

export const TestimonialsSection = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };
  
  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };
  
  return (
    <section className="py-24 bg-background relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-0 w-72 h-72 bg-violet/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-1/4 right-0 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '3s' }}></div>
      </div>
      
      <div className="max-w-6xl mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl font-futuristic font-black mb-6">
            <span className="text-violet-glow">Success</span> <span className="text-foreground">Stories</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Hear from graduates who've transformed their careers with our futuristic education platform
          </p>
        </div>
        
        {/* Main Testimonial */}
        <Card className="relative p-12 bg-gradient-card border-border/50 shadow-elevated max-w-4xl mx-auto">
          <Quote className="absolute top-8 left-8 w-12 h-12 text-primary/30" />
          
          <div className="text-center">
            {/* Stars */}
            <div className="flex justify-center gap-1 mb-6">
              {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                <Star key={i} className="w-6 h-6 fill-yellow-400 text-yellow-400" />
              ))}
            </div>
            
            {/* Testimonial Text */}
            <blockquote className="text-2xl md:text-3xl font-medium text-foreground mb-8 leading-relaxed">
              "{testimonials[currentIndex].text}"
            </blockquote>
            
            {/* Avatar and Info */}
            <div className="flex flex-col items-center">
              <Avatar className="w-20 h-20 mb-4 bg-gradient-primary border-2 border-primary">
                <div className="flex items-center justify-center w-full h-full text-primary-foreground font-futuristic font-bold text-lg">
                  {testimonials[currentIndex].avatar}
                </div>
              </Avatar>
              
              <div>
                <h4 className="text-xl font-futuristic font-bold text-neon-glow mb-1">
                  {testimonials[currentIndex].name}
                </h4>
                <p className="text-muted-foreground">
                  {testimonials[currentIndex].role}
                </p>
              </div>
            </div>
          </div>
        </Card>
        
        {/* Navigation */}
        <div className="flex justify-center items-center gap-8 mt-12">
          <Button 
            variant="hologram" 
            size="icon" 
            onClick={prevTestimonial}
            className="hover:shadow-glow"
          >
            <ChevronLeft className="w-5 h-5" />
          </Button>
          
          {/* Dots Indicator */}
          <div className="flex gap-3">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  index === currentIndex 
                    ? 'bg-primary shadow-glow scale-125' 
                    : 'bg-muted hover:bg-primary/50'
                }`}
              />
            ))}
          </div>
          
          <Button 
            variant="hologram" 
            size="icon" 
            onClick={nextTestimonial}
            className="hover:shadow-glow"
          >
            <ChevronRight className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </section>
  );
};