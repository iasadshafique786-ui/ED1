import React from 'react';
import { Button } from '@/components/ui/button';
import { Moon, Sun, Menu, Phone, Mail } from 'lucide-react';
import { useTheme } from 'next-themes';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const Header = () => {
  const { setTheme, theme } = useTheme();

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  return (
    <header className="w-full bg-background/95 backdrop-blur-sm border-b border-border sticky top-0 z-50">
      {/* Top Contact Bar */}
      <div className="hidden md:block bg-primary text-primary-foreground py-2">
        <div className="container mx-auto px-4 flex justify-between items-center text-sm">
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <Mail className="w-4 h-4" />
              <span>info@futurelearn.com</span>
            </div>
            <div className="flex items-center space-x-2">
              <Phone className="w-4 h-4" />
              <span>+1 (555) 123-4567</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-xs opacity-80">Follow us:</span>
            {/* Social icons would go here */}
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-sm">FL</span>
            </div>
            <span className="text-xl font-futuristic font-bold text-neon-glow">
              FutureLearn
            </span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a
              href="#courses"
              className="text-foreground hover:text-primary transition-colors duration-300 font-medium"
            >
              Courses
            </a>
            <a
              href="#live-sessions"
              className="text-foreground hover:text-primary transition-colors duration-300 font-medium"
            >
              Live Sessions
            </a>
            <a
              href="#join-teacher"
              className="text-foreground hover:text-primary transition-colors duration-300 font-medium"
            >
              Join as a Teacher
            </a>
            <a
              href="#about"
              className="text-foreground hover:text-primary transition-colors duration-300 font-medium"
            >
              About
            </a>
          </nav>

          {/* Right Side Actions */}
          <div className="flex items-center space-x-4">
            {/* Theme Toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="w-9 h-9 rounded-full bg-background border border-border hover:bg-accent/10"
            >
              <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              <span className="sr-only">Toggle theme</span>
            </Button>

            {/* CTA Button - Desktop */}
            <Button className="hidden md:block bg-gradient-primary hover:shadow-glow text-white font-semibold px-6">
              GET YOUR FREE SESSION
            </Button>

            {/* Mobile Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon">
                  <Menu className="w-5 h-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                align="end"
                className="w-48 bg-popover border border-border shadow-elevated"
              >
                <DropdownMenuItem asChild>
                  <a href="#courses" className="w-full cursor-pointer">
                    Courses
                  </a>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <a href="#live-sessions" className="w-full cursor-pointer">
                    Live Sessions
                  </a>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <a href="#join-teacher" className="w-full cursor-pointer">
                    Join as a Teacher
                  </a>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <a href="#about" className="w-full cursor-pointer">
                    About
                  </a>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Button className="w-full bg-gradient-primary text-white">
                    GET FREE SESSION
                  </Button>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;